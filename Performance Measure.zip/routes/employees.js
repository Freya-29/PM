const express = require('express');
const AWS = require('aws-sdk');
const app = express();
const { v4: uuidv4 } = require('uuid');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken');
const router = express.Router();

// Create a DynamoDB service object
const dynamodb = new AWS.DynamoDB();
var docClient = new AWS.DynamoDB.DocumentClient();


router.post('/employees', (req, res) => {
    let designationId;
    const params = {
      TableName: 'Designation',
      IndexName: 'designationIndex',
      KeyConditionExpression: 'designationName = :name',
      ExpressionAttributeValues: {
        ':name': req.body.designation
      }
    };

    // query the designation table to get the ID of the designation with the given name
    docClient.query(params, (err, data) => {
      if (err) {
        res.status(500).send(err);
      } else {
        designationId = data.Items[0].id;
        // res.send(`${req.body.designation}: ${designationId}`);

        const params2 = {
          TableName: 'Employee',
          Item: {
            id: "USER:" + uuidv4(),
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            designation: designationId,
            department: req.body.department,
            type: req.body.type
          }
        };
        docClient.put(params2, (err, data) => {
          if (err) {
            res.status(500).send(err);
          } else {
            res.send(data);
          }
        });
      }
    });

  });


  router.get(`/employees`, (req, res) =>{
    const params = {
      TableName : "Employee"
    };
  docClient.scan(params, (err, data) => {
      if (err) {
          console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
      } else {
          res.send(data);
      }
    })
  })

  router.get('/employees/:id', function (req, res) {
    var userId = req.params.id;
    var params = {
          TableName : "Employee",
          KeyConditionExpression: "#id = :id" ,
          ExpressionAttributeNames:{
              "#id": "id"
          },
          ExpressionAttributeValues: {
              ":id": userId
          }
      };
      docClient.query(params, function(err, data) {
        if (err) {
            console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
        } else {
            console.log("Query succeeded.");
            res.send(data)
        }
    });
    });
  
    router.delete('/employees/:id', function (req, res) {
      var userId = req.params.id;
      var params = {
            TableName : "Employee",
            Key: {
              "id": userId
            }
        };
        docClient.delete(params, function(err, data) {
          if (err) {
              console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
          }else{
            res.send(data);
          }
      });
      });

  module.exports = router;